<?php

if (isset($_FILES['pict']['name'])) {
        
    $imageFileType = strtolower(pathinfo($_FILES['pict']['name'],PATHINFO_EXTENSION));
    
    if($_FILES['pict']['size'] > 1000000){
        if($_FILES['pict']['size'] > 1000000){ 
            echo '<br><b>Too Large (file cannot be more than 1mb)</b>';
        }
    }else{
        $filename = $_FILES['pict']['name'];
        $location = "profile_pict/" . $filename;
        
        if (move_uploaded_file($_FILES['pict']['tmp_name'], $location)) {
            echo '<br><b>Uploaded!!!</b>';
        }
    }   
}
?>