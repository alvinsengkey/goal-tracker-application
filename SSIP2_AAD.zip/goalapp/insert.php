<?php
require_once '../conn_db.php';

$category = mysqli_real_escape_string($conn, $_REQUEST['cat']);
$text = mysqli_real_escape_string($conn, $_REQUEST['text']);
$date = mysqli_real_escape_string($conn, $_REQUEST['date']);
$complete = mysqli_real_escape_string($conn, $_REQUEST['complete']);

$query = "INSERT INTO goals (goal_category, goal_text, goal_date, goal_complete) VALUES ";
$query .= "('" . $category . "',";
$query .= "'" . $text . "',";
$query .=  "'" . $date . "',";
$query .= "'" .$complete . "')";

$res = mysqli_query($conn, $query);
?>