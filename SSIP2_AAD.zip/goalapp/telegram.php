<?php

$telegram_id = $_POST['tele_id'];
$message_text = "New goal:\r\n" . $_POST['text'] . "\r\nGoal Date:\r\n" . $_POST['goaldate'];
$secret_token = '2134673387:AAHCATZsPGDfITpvGatZEX8TOSL5pe10_6c';
sendMessage($telegram_id, $message_text, $secret_token);

function sendMessage($telegram_id, $message_text, $secret_token) {
    $url = "https://api.telegram.org/bot" . $secret_token . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode($message_text);
    $ch = curl_init();
    $optArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    if ($err) {
       echo 'Pesan gagal terkirim, error :' . $err;
    }else{
        echo 'Pesan terkirim';
    }
}
echo "<script>location.href='goalapp.php'</script>";
?>
