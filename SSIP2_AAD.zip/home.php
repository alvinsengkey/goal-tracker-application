<?php
    session_start();

    if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
        href="https://api.tiles.mapbox.com/mapbox-gl-js/v2.6.0/mapbox-gl.css"
        rel="stylesheet"/>
    <script src="https://api.tiles.mapbox.com/mapbox-gl-js/v2.6.0/mapbox-gl.js"></script>
    <link rel="stylesheet" href="maps.css" />
    <title>Home</title>
</head>

<body>
    <h1>Hello, <?php echo $_SESSION['name']; ?></h1>
    <a href="logout.php">Logout</a>
    <a href="goalapp\goalapp.php">Goal app</a>
    <a href="matrix\matrix.php">Matrix Multiplication</a>
    <a href="maps.html">President University Location</a>
    <div>


</body>
</html>

<?php 
    }
    else {
        header("Location: index.php");
        exit();
    }
?>