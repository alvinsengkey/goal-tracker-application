<?php

$conn = mysqli_connect('sql103.epizy.com', 'epiz_30534707', 'OZn8Uw41VATL', 'epiz_30534707_db_1');

if (!$conn) {
        echo "db connection failed!";
    }
?>